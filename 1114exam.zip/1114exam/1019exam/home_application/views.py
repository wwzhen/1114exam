# -*- coding: utf-8 -*-
import base64

from blueking.component.shortcuts import get_client_by_request
from common.mymako import render_mako_context, render_json
from home_application.models import ExecuteRecord


def home(request):
    """
    首页
    """
    biz_list = get_biz_list(request)
    return render_mako_context(request, '/home_application/index.html',
                               {'biz_list': biz_list})


def get_biz_list(request):
    client = get_client_by_request(request)
    result = client.cc.search_business()
    if result['result']:
        return result['data']['info']
    else:
        return []


def get_biz_topo(request):
    bk_biz_id = request.POST.get('bk_biz_id')
    kwargs = {
        'bk_supplier_account': 0,
        'bk_biz_id': int(bk_biz_id)
    }
    client = get_client_by_request(request)
    result = client.cc.search_biz_inst_topo(kwargs)
    if result['result']:
        topo_data = process_biz_topo_data(result['data'])
        return render_json({"result": True, "data": topo_data})
    else:
        return []


def process_biz_topo_data(data):
    result = list()
    if len(data) > 0:
        for item in data:
            child_data = dict()
            child_data['id'] = item['bk_inst_id']
            child_data['text'] = item['bk_inst_name']
            child_data['obj_id'] = item['bk_obj_id']
            child_data['children'] = process_biz_topo_data(item['child'])
            result.append(child_data)
    return result


def get_host_list(request):
    bk_biz_id = request.POST.get('bk_biz_id')
    type_id = request.POST.get('type_id')
    value = request.POST.get('value')
    condition = [
        {
            "bk_obj_id": "biz",
            "fields": [],
            "condition": [
                {
                    "field": "bk_biz_id",
                    "operator": "$eq",
                    "value": int(bk_biz_id)
                }
            ]
        }
    ]

    if type_id == 'set':
        condition.append(
            {
                "bk_obj_id": "set",
                "fields": [],
                "condition": [
                    {
                        "field": "bk_set_id",
                        "operator": "$eq",
                        "value": int(value)
                    }
                ]
            }
        )
    if type_id == 'module':
        condition.append(
            {
                "bk_obj_id": "module",
                "fields": [],
                "condition": [
                    {
                        "field": "bk_module_id",
                        "operator": "$eq",
                        "value": int(value)
                    }
                ]
            }
        )
    kwargs = {
        'bk_supplier_account': "0",
        "condition": condition
    }
    client = get_client_by_request(request)
    result = client.cc.search_host(kwargs)
    if result['result']:
        return render_json({"result": True, "data": result['data']['info']})


def search_file(request):
    client = get_client_by_request(request)
    path = request.POST.get('path')
    suffix = request.POST.get('fileName')
    bk_biz_id = int(request.POST.get('bkBizId'))
    ips = request.POST.get('ipList')
    ips = ips.split('\n')
    ip_list = list()
    for ip in ips:
        ip_list.append(
            {
                "bk_cloud_id": 0,
                "ip": str(ip)
            }
        )
    script_content = "cd $1 \n ls *.$2 -l | awk '{ print $5, $9}' "
    script_param = path + " " + suffix
    kwargs = {
        'bk_biz_id': bk_biz_id,
        "script_content": base64.b64encode(script_content),
        "script_param": base64.b64encode(script_param),
        "account": "root",
        "script_type": 1,
        "ip_list": ip_list
    }
    result = client.job.fast_execute_script(kwargs)
    if result['result']:
        job_instance_id = result['data']['job_instance_id']
        log = get_execute_log(job_instance_id, client, bk_biz_id)
        while not log['result']:
            log = get_execute_log(job_instance_id, client, bk_biz_id)
        return render_json(log)
    else:
        return render_json()


def get_execute_log(job_instance_id, client, bk_biz_id):
    kwargs = {
        "bk_biz_id": bk_biz_id,
        "job_instance_id": job_instance_id
    }
    status_result = client.job.get_job_instance_status(kwargs)
    if status_result['result']:
        if status_result['data']['is_finished']:
            log_result = client.job.get_job_instance_log(kwargs)
            if log_result['result']:
                result = log_result['data'][0]['step_results'][0]['ip_logs']
                return {'result': True, "data": result}
        else:
            return {"result": False}
    else:
        return {"result": False}


def file_backup(request):
    path = request.POST.get('path')
    file_name = request.POST.get('fileName')
    file_str = request.POST.get('file')
    num = request.POST.get('num')
    size = request.POST.get('size')
    ip = request.POST.get('ip')
    client = get_client_by_request(request)
    bk_biz_id = int(request.POST.get('bkBizId'))
    job_detail_result = get_job_detail(client, bk_biz_id)
    steps = job_detail_result['steps']
    global_vars = job_detail_result['global_vars']
    step_ip_list = [
        {
            "bk_cloud_id": 0,
            "ip": str(ip)
        }
    ]
    steps[0]['ip_list'] = step_ip_list
    script_params = str(path + ' ' + file_name + ' ' + 'wanwenzhen1019.zip')
    steps[0]['script_param'] = base64.b64encode(script_params)
    global_vars[0]['ip_list'] = step_ip_list
    source_file = path + '/' + 'wanwenzhen1019.zip'
    steps[1]['file_source'] = [
        {
            "files": [source_file],
            "account": "root",
            "ip_list": step_ip_list
        }
    ]
    result = execute_job(steps, bk_biz_id, global_vars, client)
    if result['result']:
        record_dict = {
            "user": request.user.username,
            "ip": ip,
            "file": file_str,
            "num": num,
            "size": size,
            "status": "1",
            "job_instance_id": result['data']['job_instance_id'],
            "creator": request.user.username
        }
        ExecuteRecord.objects.create(**record_dict)
        return render_json({"result": True})
    else:
        return render_json({"result": False, "message": result['message']})


def execute_job(steps, bk_biz_id, global_vars, client):
    kwargs = {
        "bk_biz_id": bk_biz_id,
        "bk_job_id": 132,
        "steps": steps,
        'global_vars': global_vars
    }
    result = client.job.execute_job(kwargs)
    return result


def get_job_detail(client, bk_biz_id, bk_job_id=132):
    kwargs = {
        "bk_biz_id": int(bk_biz_id),
        "bk_job_id": int(bk_job_id)
    }
    result = client.job.get_job_detail(kwargs)
    if result['result']:
        return result['data']
    else:
        return None


def history(request):
    execute_qs_list = ExecuteRecord.objects.filter().order_by('-created')
    execute_list = list()
    for execute in execute_qs_list:
        item = execute.to_dict()
        item[
            'job_url'] = "http://job-bkyovole.cloud.yovole.com/?taskInstanceList&appId=28#taskInstanceId=" + execute.job_instance_id
        execute_list.append(item)
    return render_mako_context(request, '/home_application/history.html', {"execute_list": execute_list})
