# -*- coding: utf-8 -*-


from datetime import datetime

from django.db import models
from django.db.models import DateTimeField


class ExecuteRecord(models.Model):
    user = models.CharField(max_length=16)
    job_instance_id = models.CharField(max_length=64)
    ip = models.CharField(max_length=64)
    file = models.TextField()
    num = models.CharField(max_length=256)
    size = models.CharField(max_length=16)
    created = models.DateTimeField(default=datetime.now)
    creator = models.CharField(max_length=255)
    status = models.IntegerField()

    def to_dict(self, fields=None, exclude=None):
        data = {}
        for f in self._meta.concrete_fields + self._meta.many_to_many:
            value = f.value_from_object(self)
            if fields and f.name not in fields:
                continue
            if exclude and f.name in exclude:
                continue
            if isinstance(f, DateTimeField):
                value = value.strftime('%Y-%m-%d %H:%M:%S') if value else None
            data[f.name] = value
        return data
