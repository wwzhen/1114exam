# -*- coding: utf-8 -*-

from django.conf.urls import patterns

urlpatterns = patterns(
    'home_application.views',
    (r'^$', 'home'),
    (r'^get_biz_topo/$', 'get_biz_topo'),
    (r'^get_host_list/$', 'get_host_list'),
    (r'^search_file/$', 'search_file'),
    (r'^file_backup/$', 'file_backup'),
    (r'^history/$', 'history'),
)
