# SaaS开发机试说明

- 考试时间2019年9月26日 09:00 ~ 13:00 总共4个小时, 考试在规定时间内答题
- 考试仅包含SaaS开发机试，按要求完成SaaS开发并部署到蓝鲸考试环境的"测试环境"
- 考试时间结束，考生需把考试SaaS打包发送给Jacky，以便做明细评分使用
- 考试结果将在两天内公开公布，下周安排开始分析和点评
- 考试要求考生务必看清楚，python 代码要符合pep8规范，评分时会酌情对考生不规范的代码进行相应的扣分

## 1. 考试环境说明
- 蓝鲸考试环境host配置
   ```bash
    172.19.11.12 paas.blueking.yovole.tech
    172.19.11.12 cmdb.blueking.yovole.tech
    172.19.11.12 job.blueking.yovole.tech
    ```
- 蓝鲸环境 https://paas-bkyovole.cloud.yovole.com 使用各自用户名密码登录，有问题找Jacky
```json
    lipeng
    duxiaomin
    wanwenzhen
    huangjing
    linjing
    sunxiaoqiang
    donghuan
    
    密码: Bk@123456
    
    应用名称用自己的用户名，白名单中已经添加
```
- 数据库 10.3.33.7 连接账号及密码root, root，每个考生使用自己的姓名拼音加_t 作为testing环境的数据库，本地开发数据库自己在本地搭建

## 2. 考试要求
- 使用蓝鲸考试环境的 **python开发框架2.0版本** 进行SaaS开发,下载地址 (http://bkopen-1252002024.file.myqcloud.com/open/framework.tar.gz)
- 按照该地址的SaaS（https://paas-bkyovole.cloud.yovole.com/t/bk_funds_manage/）实现一个一样的SaaS

## 3. 考试涉及到的接口
- 获取用户列表接口 http://paas.blueking.yovole.tech/esb/api_docs/system/USERMANAGE/get_all_users/