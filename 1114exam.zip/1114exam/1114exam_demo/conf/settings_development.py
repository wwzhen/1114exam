# -*- coding: utf-8 -*-
"""
用于本地开发环境的全局配置
"""

# ===============================================================================
# 数据库设置, 本地开发数据库设置
# ===============================================================================
import os

from conf.default import BASE_DIR

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',  # 默认用mysql
        "NAME": os.path.join(BASE_DIR, 'db.sqlite3'),
    },
}

# DATABASES = {
#     'default': {
#         'ENGINE': 'django.db.backends.mysql',  # 默认用mysql
#         'NAME': 'wanwenzhen_1114',  # 数据库名 (默认与APP_ID相同)
#         'USER': 'root',  # 你的数据库user
#         'PASSWORD': '111111',  # 你的数据库password
#         'HOST': '127.0.0.1',  # 数据库HOST
#         'PORT': '3306',  # 默认3306
#     },
# }
