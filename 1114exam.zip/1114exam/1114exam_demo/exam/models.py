# coding=utf-8
from datetime import datetime

from django.db import models
# Create your models here.
from django.forms import DateTimeField


class UserInfo(models.Model):
    account = models.CharField(max_length=255)
    email = models.CharField(max_length=64)
    password = models.CharField(max_length=255)
    area = models.CharField(max_length=255)
    gender = models.CharField(max_length=16)
    desc = models.TextField()
    birthday = models.CharField(max_length=255)
    hobby = models.CharField(max_length=255)
    file = models.FileField(upload_to='file/')


class ExecuteRecord(models.Model):
    user = models.CharField(max_length=16)
    script_name = models.CharField(max_length=64)
    bk_biz_id = models.CharField(max_length=64)
    bk_biz_name = models.CharField(max_length=64)
    host_list = models.CharField(max_length=256)
    job_instance_id = models.CharField(max_length=16)
    is_finished = models.BooleanField(default=False)
    created = models.DateTimeField(default=datetime.now)
    creator = models.CharField(max_length=255)
    status = models.IntegerField()
    log = models.TextField(null=True, blank=True)

    def to_dict(self, fields=None, exclude=None):
        data = {}
        for f in self._meta.concrete_fields + self._meta.many_to_many:
            value = f.value_from_object(self)
            if fields and f.name not in fields:
                continue
            if exclude and f.name in exclude:
                continue
            if isinstance(f, DateTimeField):
                value = value.strftime('%Y-%m-%d %H:%M:%S') if value else None
            data[f.name] = value
        return data

    class Meta:
        verbose_name = u"执行记录"
        verbose_name_plural = verbose_name
