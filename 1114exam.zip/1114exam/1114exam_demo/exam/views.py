# coding=utf-8
# Create your views here.
import base64
from datetime import date

import xlrd as xlrd
import xlwt as xlwt
from django.db.models import Q, Count
from django.http import FileResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt

from blueking.component.shortcuts import get_client_by_request
from common.mymako import render_mako_context, render_json
from exam.models import UserInfo


def form(request):
    return render_mako_context(request, "/exam/form.html")


def user_add(request):
    print request.POST['date']
    kwargs = {
        "account": request.POST['account'],
        "email": request.POST['email'],
        "password": base64.encodestring(request.POST['password']),
        "area": request.POST['area'],
        "gender": request.POST['gender'],
        "desc": request.POST['desc'],
        "file": request.FILES.get('file'),
        "birthday": request.POST['date'],
        "hobby": request.POST['hobby']
    }
    UserInfo.objects.create(**kwargs)
    return render_json({"result": True})


def table(request):
    return render_mako_context(request, '/exam/datatable.html')


def jstree(request):
    return render_mako_context(request, '/exam/tree.html')


def table_data(request):
    account = request.POST.get("name", "")
    email = request.POST.get("email", "")
    search_date = request.POST.get("date", "")
    q_query = Q()
    if account:
        q_query = q_query & Q(account__contains=account)
    if email:
        q_query = q_query & Q(email__contains=email)
    if search_date:
        q_query = q_query & Q(birthday__lte=search_date)
    user_list = list(
        UserInfo.objects.filter(q_query).values("id", "account", "email", "password", "area", "gender", "desc",
                                                "birthday",
                                                "hobby", "file").order_by("-id"))
    return render_json({"result": True, "user_list": user_list})


def download(request):
    user_id = request.GET.get("id")
    user = UserInfo.objects.get(id=user_id)
    user_file_address = user.file.name
    user_file = open(user_file_address, 'rb')
    file_name = user_file_address[user_file_address.index('/'):len(user_file_address)]
    response = FileResponse(user_file)
    response['Content-type'] = 'application/octet-stream'
    response['Content-Disposition'] = 'attachment;filename=' + file_name
    return response


def user_delete(request):
    user_id = request.POST.get("id")
    UserInfo.objects.get(id=user_id).delete()
    return render_json({"result": True})


def echarts(request):
    return render_mako_context(request, '/exam/echarts.html')


def echarts_data(request):
    # test = request.POST.get("test")
    gender_info_list = UserInfo.objects.values("gender").annotate(Count("gender")).order_by()
    series = list()
    for gender_info in gender_info_list:
        item = {
            "value": gender_info['gender__count'],
            "name": gender_info['gender']
        }
        series.append(item)
    data = {
        "title": "",
        "series": series
    }
    return render_json({"result": True, "data": data, "code": 0, "message": "success"})


def bar_chart_data(request):
    gender_info_list = UserInfo.objects.values("gender").annotate(Count("gender")).order_by()
    series_data = list()
    xaxis_data = list()
    for gender_info in gender_info_list:
        xaxis_data.append(gender_info['gender'])
        series_data.append(gender_info['gender__count'])
    series_list = list()
    xaxis_list = list()
    xaxis = {
        "type": "category",
        "data": xaxis_data
    }
    series = {
        "type": "bar",
        "name": "count",
        "data": series_data
    }
    series_list.append(series)
    xaxis_list.append(xaxis)
    data = {
        "xAxis": xaxis_list,
        "series": series_list
    }
    print data
    return render_json({"result": True, "data": data, "code": 0, "message": "success"})


def components(request):
    return render_mako_context(request, '/exam/components.html')


def export(request):
    workbook = xlwt.Workbook()
    worksheet = workbook.add_sheet('user_info')
    user_list = list(
        UserInfo.objects.filter().values("id", "account", "email", "password", "gender", "desc", "birthday",
                                         "hobby"))
    title = ["ID", u"账号", u"邮箱", u"密码", u"性别", u"描述", u"生日", u"爱好"]
    for i in range(len(title)):
        worksheet.write(0, i, title[i], set_style('Times New Roman', 220, True))
    for i in range(len(user_list)):
        worksheet.write(i + 1, 0, user_list[i]['id'])
        worksheet.write(i + 1, 1, user_list[i]['account'])
        worksheet.write(i + 1, 2, user_list[i]['email'])
        worksheet.write(i + 1, 3, base64.decodestring(user_list[i]['password']))
        worksheet.write(i + 1, 4, user_list[i]['gender'])
        worksheet.write(i + 1, 5, user_list[i]['desc'])
        worksheet.write(i + 1, 6, user_list[i]['birthday'])
        worksheet.write(i + 1, 7, user_list[i]['hobby'])
    response = HttpResponse(content_type="application/msexcel")
    response['Content-Disposition'] = 'attachment;filename=user_info.xls'
    workbook.save(response)
    return response


@csrf_exempt
def import_user_info(request):
    user_file = request.FILES.get('userInfo')
    wb = xlrd.open_workbook(filename=None, file_contents=user_file.read())
    work_sheet = wb.sheet_by_index(0)
    for i in range(work_sheet.nrows):
        if i == 0:
            continue
        kwargs = {
            "account": work_sheet.cell(i, 0).value.encode('utf-8'),
            "email": work_sheet.cell(i, 1).value.encode('utf-8'),
            "password": base64.encodestring(str(work_sheet.cell(i, 2).value).encode('utf-8')),
            "gender": work_sheet.cell(i, 3).value.encode('utf-8'),
            "desc": work_sheet.cell(i, 4).value.encode('utf-8'),
            "birthday": date(*(xlrd.xldate_as_tuple(work_sheet.cell_value(i, 5), wb.datemode))[:3]).strftime(
                "%Y-%m-%d"),
            "hobby": work_sheet.cell(i, 6).value.encode('utf-8')
        }
        UserInfo.objects.create(**kwargs)
    return render_mako_context(request, "/exam/datatable.html")


def set_style(name, height, bold=False):
    style = xlwt.XFStyle()  # 初始化样式

    font = xlwt.Font()  # 为样式创建字体
    font.name = name  # 'Times New Roman'
    font.bold = bold
    font.color_index = 4
    font.height = height
    style.font = font
    return style


def search_host_by_topo(request):
    client = get_client_by_request(request)
    bk_biz_id = int(request.POST.get('bk_biz_id'))
    obj_id = int(request.POST.get('obj'))
    obj = request.POST.get('obj')
    ip = request.POST.get('ip')
    ip_list = list()
    if ip:
        ip_list = ip.split('\n')
    host_name = request.POST.get('host_name')
    start_time = request.POST.get('start_time')
    end_time = request.POST.get('end_time')
    condition = []
    if obj == 'biz':
        condition += [
            {
                'bk_obj_id': 'biz',
                'fields': [],
                'condition': [
                    {
                        'field': 'bk_biz_id',
                        'operator': '$eq',
                        'value': bk_biz_id
                    }
                ]
            },
            {
                "bk_obj_id": "set",
                "fields": [],
                "condition": []
            },
            {
                "bk_obj_id": "module",
                "fields": [],
                "condition": []
            },
            {
                "bk_obj_id": "object",
                "fields": [],
                "condition": []
            }
        ]
    elif obj == 'set':
        condition += [
            {
                'bk_obj_id': 'biz',
                'fields': [],
                'condition': []
            },
            {
                "bk_obj_id": "set",
                "fields": [],
                "condition": [
                    {
                        'field': 'bk_set_id',
                        'operator': '$eq',
                        'value': obj_id
                    }
                ]
            },
            {
                "bk_obj_id": "module",
                "fields": [],
                "condition": []
            },
            {
                "bk_obj_id": "object",
                "fields": [],
                "condition": []
            }
        ]
    elif obj == 'module':
        condition += [
            {
                'bk_obj_id': 'biz',
                'fields': [],
                'condition': []
            },
            {
                "bk_obj_id": "set",
                "fields": [],
                "condition": []
            },
            {
                "bk_obj_id": "module",
                "fields": [],
                "condition": [
                    {
                        'field': 'bk_module_id',
                        'operator': '$eq',
                        'value': obj_id
                    }
                ]
            },
            {
                "bk_obj_id": "object",
                "fields": [],
                "condition": []
            }
        ]
    elif obj:
        condition += [
            {
                'bk_obj_id': 'biz',
                'fields': [],
                'condition': []
            },
            {
                "bk_obj_id": "set",
                "fields": [],
                "condition": []
            },
            {
                "bk_obj_id": "module",
                "fields": [],
                "condition": []
            },
            {
                "bk_obj_id": "object",
                "fields": [],
                "condition": [
                    {
                        'bk_obj_id': obj,
                        'operator': '$eq',
                        'value': obj_id
                    }
                ]
            }
        ]
    host_condition = list()
    if len(ip_list) > 0:
        host_condition += [
            {
                'field': 'bk_host_innerip',
                'operator': '$in',
                'value': ip_list
            }
        ]
    if host_name:
        host_condition += [
            {
                'field': 'bk_host_name',
                'operator': '$regex',
                'value': host_name
            }
        ]
    if start_time and end_time:
        host_condition += [
            {
                'field': 'create_time',
                'operator': '$gte',
                'value': start_time
            },
            {
                'field': 'create_time',
                'operator': '$lte',
                'value': end_time
            }
        ]
    condition += [
        {
            'bk_obj_id': 'host',
            'fields': [],
            'condition': host_condition
        }
    ]
    kwargs = {
        'bk_biz_id': bk_biz_id,
        'condition': condition
    }
    result = client.cc.search_host(kwargs)
    host_list = list()
    if result['result']:
        host_list = result['data']['info']
    return render_json({"result": True, 'host_list': host_list})


def get_biz_topo(request):
    client = get_client_by_request(request)
    bk_biz_id = request.POST.get("bk_biz_id")
    kwargs = {
        "bk_biz_id": bk_biz_id,
        "bk_supplier_account": "0"
    }
    result = client.cc.search_biz_inst_topo(kwargs)
    if result['result']:
        data = result['data']
        topo_data = format_topo_data(data)
        return render_json({"result": True, "data": topo_data})
    else:
        return render_json({"result": False})


def format_topo_data(data):
    result = list()
    if len(data) > 0:
        for item in data:
            child_result = dict()
            child_result['id'] = item['bk_inst_id']
            child_result['text'] = item['bk_inst_name']
            child_result['obj_id'] = item['bk_obj_id']
            child_result['children'] = format_topo_data(item['child'])
            result.append(child_result)
    return result


def get_job_detail(request):
    client = get_client_by_request(request)
    bk_biz_id = request.POST.get('bk_biz_id', 28)
    kwargs = {
        'bk_biz_id': bk_biz_id,
        'bk_job_id': 132
    }
    result = client.job.get_job_detail(kwargs)
    if result['result']:
        return render_json(result['data'])


def execute_job(request, steps):
    client = get_client_by_request(request)
    bk_biz_id = request.POST.get('bk_biz_id', 28)
    kwargs = {
        'bk_biz_id': bk_biz_id,
        'bk_job_id': 100,
        'steps': steps  # 替换steps中的ip_list
    }
    result = client.job.execute_job(kwargs)
    if result['result']:
        return render_json({"result": True})


def get_script_detail(request):
    client = get_client_by_request(request)
    bk_biz_id = request.POST.get('bk_biz_id', 28)
    kwargs = {
        'bk_biz_id': bk_biz_id,
        'id': 100
    }
    result = client.job.get_script_detail(kwargs)
    if result['result']:
        return render_json({"result": True})


def fast_execute_script(request):
    client = get_client_by_request(request)
    bk_biz_id = request.POST.get('bk_biz_id', 28)
    kwargs = {
        'bk_biz_id': bk_biz_id,
        'script_id': 100,
        'ip_list': [
            {
                'ip': '10.3.33.7',
                'bk_cloud_id': 0
            }
        ]
    }
    result = client.job.fast_execute_script(kwargs)
    if result['result']:
        return render_json({"result": True})
