# -*- coding: utf-8 -*-

from django.conf.urls import patterns

urlpatterns = patterns(
    'exam.views',
    (r'^$', 'form'),
    (r'^user/add/', 'user_add'),
    (r'^user/delete/', 'user_delete'),

    (r'^table/$', 'table'),
    (r'^datatable/data/$', 'table_data'),
    (r'^file/download/$', 'download'),

    (r'^export/$', 'export'),
    (r'^import/user_info/$', 'import_user_info'),

    (r'^echarts/$', 'echarts'),
    (r'^echarts/data/$', 'echarts_data'),
    (r'^bar_echarts/data/$', 'bar_chart_data'),

    (r'^components/$', 'components'),

    (r'^jstree/$', 'jstree'),

    (r'^get_job_detail_test/$', 'get_job_detail'),
)
