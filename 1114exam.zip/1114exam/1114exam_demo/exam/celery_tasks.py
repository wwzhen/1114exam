# -*- coding: utf-8 -*-
"""
celery 任务示例

本地启动celery命令: python  manage.py  celery  worker  --settings=settings
周期性任务还需要启动celery调度命令：python  manage.py  celerybeat --settings=settings
"""
import json

from celery.schedules import crontab
from celery.task import periodic_task

from blueking.component.shortcuts import get_client_by_user
from common.log import logger
from conf.default import DEFAULT_USER
from exam.models import ExecuteRecord


@periodic_task(run_every=crontab(minute='*/1', hour='*', day_of_week="*"))
def get_job_instance_status():
    logger.debug("start!!!!!!!!!!")
    unfinished_job = ExecuteRecord.objects.filter(is_finished=False)
    if unfinished_job.exists():
        client = get_client_by_user(DEFAULT_USER)
        for job in unfinished_job:
            kwargs = {
                'bk_biz_id': job.bk_biz_id,
                'job_instance_id': job.job_instance_id
            }
            job_status = client.job.get_job_instance_status(**kwargs)
            if job_status:
                if job_status['result']:
                    if job_status['data']['is_finished']:
                        job.status = job_status['data']['job_instance']['status']
                        job.is_finished = True
                        job_logs = get_job_instance_log(client, job.bk_biz_id, job.job_instance_id)
                        job.log = json.dumps(job_logs['data'][0]['step_results'])
                        job.save()
                        logger.info("update job log done")


def get_job_instance_log(client, bk_biz_id, job_instance_id):
    kwargs = {
        "bk_biz_id": bk_biz_id,
        "job_instance_id": job_instance_id
    }
    job_logs = client.job.get_job_instance_log(**kwargs)
    return job_logs
