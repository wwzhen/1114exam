# -*- coding: utf-8 -*-

from django.conf.urls import patterns

urlpatterns = patterns(
    'home_application.views',
    (r'^$', 'home'),
    (r'^host/list/$', 'get_host_list'),
    (r'^execute/page/$', 'execute_page'),
    (r'^execute/sql/$', 'execute_sql'),
)
