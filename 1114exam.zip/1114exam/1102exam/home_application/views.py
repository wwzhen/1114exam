# -*- coding: utf-8 -*-
import json
import time

from blueking.component.shortcuts import get_client_by_request
from common.mymako import render_mako_context, render_json


def home(request):
    """
    首页
    """
    client = get_client_by_request(request)
    biz_list = get_biz_list(client)
    return render_mako_context(request, '/home_application/index.html', {'biz_list': biz_list})


def execute_page(request):
    client = get_client_by_request(request)
    biz_list = get_biz_list(client)
    bk_biz_id = request.GET.get('bk_biz_id', 17)
    script_list = get_script_list(client, bk_biz_id)
    db_account_list = get_db_account_list(client, bk_biz_id)
    host = get_host_by_attribute(client, bk_biz_id)
    return render_mako_context(request, '/home_application/sql.html',
                               {'biz_list': biz_list, 'script_list': script_list, 'db_account_list': db_account_list,
                                'host': host, 'select_biz': int(bk_biz_id)})


def get_biz_list(client):
    result = client.cc.search_business()
    biz_list = []
    if result['result']:
        biz_list = result['data']['info']
    return biz_list


def get_host_list(request):
    client = get_client_by_request(request)
    biz_id = int(request.GET.get('bk_biz_id', 17))
    data = search_host(client, biz_id)
    return render_json({"result": True, "host_list": data})


def get_host_attribute(client, bk_property_name=u'设备名称/型号'):
    kwargs = {
        'bk_obj_id': 'host',
        'bk_supplier_account': "0"
    }
    result = client.cc.search_object_attribute(kwargs)
    attribute_id = None
    if result['result']:
        attribute_list = result['data']
        for attribute in attribute_list:
            if attribute['bk_property_name'] == bk_property_name:
                attribute_id = attribute['bk_property_id']
    return attribute_id


def get_db_account_list(client, bk_biz_id):
    kwargs = {
        'bk_biz_id': bk_biz_id
    }
    result = client.job.get_own_db_account_list(kwargs)
    db_account_list = list()
    if result['result']:
        db_account_list = result['data']
    return db_account_list


def get_script_list(client, bk_biz_id, script_type='6'):
    kwargs = {
        'bk_biz_id': bk_biz_id,
        'script_type': script_type
    }
    result = client.job.get_script_list(kwargs)
    script_list = list()
    if result['result']:
        script_list = result['data']['data']
    return script_list


def search_host(client, biz_id):
    kwargs = {
        "bk_supplier_account": "0",
        "condition": [
            {
                "bk_obj_id": "host",
                "fields": [],
                "condition": []
            },
            {
                "bk_obj_id": "module",
                "fields": [],
                "condition": []
            },
            {
                "bk_obj_id": "set",
                "fields": [],
                "condition": []
            },
            {
                "bk_obj_id": "biz",
                "fields": [],
                "condition": [
                    {
                        "field": "bk_biz_id",
                        "operator": "$eq",
                        "value": biz_id
                    }
                ]
            },
            {
                "bk_obj_id": "object",
                "fields": [],
                "condition": []
            }
        ]
    }
    result = client.cc.search_host(kwargs)
    data = list()
    if result['result']:
        data = result['data']['info']
    return data


def get_host_by_attribute(client, bk_biz_id, attribute_value='BLUEKING-DEV-MYSQL'):
    attribute_id = get_host_attribute(client)
    host_list = search_host(client, int(bk_biz_id))
    host = None
    if host_list:
        for host_item in host_list:
            if host_item['host'][attribute_id] == attribute_value:
                host = host_item
    return host


def execute_sql(request):
    client = get_client_by_request(request)
    script_id = request.POST.get('script_id', 1897)
    bk_biz_id = request.POST.get('bk_biz_id', 17)
    db_account_id = request.POST.get('db_account_id', 0)
    ip_list = json.loads(request.POST.get('ip_list'))
    kwargs = {
        'script_id': int(script_id) if script_id else 1897,
        'bk_biz_id': bk_biz_id,
        'ip_list': ip_list,
        'db_account_id': int(db_account_id) if db_account_id else 0
    }
    result = client.job.fast_execute_sql(kwargs)
    if not result['result']:
        return render_json({"result": False, "message": result['message']})
    else:
        job_instance_id = result['data']['job_instance_id']
        result = get_job_execute_status(client, bk_biz_id, job_instance_id)
        while not result:
            time.sleep(1)
            result = get_job_execute_status(client, bk_biz_id, job_instance_id)
        return render_json({"result": True, "data": result})


def get_job_execute_status(client, bk_biz_id, job_instance_id):
    kwargs = {
        "bk_biz_id": bk_biz_id,
        "job_instance_id": job_instance_id
    }
    result = client.job.get_job_instance_status(kwargs)
    if result['result']:
        if result['data']['is_finished']:
            execute_log = get_job_execute_detail(client, bk_biz_id, job_instance_id)
            return execute_log
        else:
            return None


def get_job_execute_detail(client, bk_biz_id, job_instance_id):
    kwargs = {
        "bk_biz_id": bk_biz_id,
        "job_instance_id": job_instance_id
    }
    result = client.job.get_job_instance_log(kwargs)
    if result['result']:
        return result['data'][0]['step_results'][0]['ip_logs'][0]['log_content']
